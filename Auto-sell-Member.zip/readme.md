# رابط الشرح :
# https://mega.nz/file/szB3iDLR#b22pvQC837HwP_2800eZOX9DTWCW3Tq8G6gudNMWhT4

# سيرفر الدعم الفني : https://discord.gg/g-p
