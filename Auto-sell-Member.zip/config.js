module.exports = {
  bot: {
    owners: [""],  // اونر
    botID: "",    // ايدي البوت
    GuildId: "",   // ايدي السيرفير
    ClientId: "",    // ايدي البوت
    serverinvte: "", // انفايت سير
    clientSECRET: process.env.client , // سكريت
    callbackURL: "/login", // الكال باك
    inviteBotUrl: "",// انفايت البوت
    TheLinkVerfy : '', // رابط اوثو رايز بالصلاحيه ادخال الي سيرفرات
    prefix : '$', 
    ceatogry : '', // كاتوجري الي يفتح فيها تكت شراء
     TOKEN: (process.env.midd),// توكن 
    Price: 800,    // سعر العضو الواحد
    TraId  : '' // الي يتحوله كريديت
  },
  website: {
    PORT: "3001",
  }
}